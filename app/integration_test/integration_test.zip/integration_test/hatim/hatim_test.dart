import 'package:flutter/foundation.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mq_ci_keys/mq_ci_keys.dart';
import '../extensions/extensions.dart';

Future<void> checkHatimJuzs(WidgetTester tester) async {
  await tester.pumpAndSettle();
  expect(find.byKey(const ValueKey(MqKeys.hatimPage)), findsOneWidget);
  expect(find.byKey(const ValueKey(MqKeys.hatimJuzsList)), findsOneWidget);
  await tester.takeScreenshot(Screenshots.hatimJuzs);
}

Future<void> tapHatimJuz(WidgetTester tester) async {
  await tester.pumpAndSettle();
  await tester.tap(find.byKey(ValueKey(MqKeys.hatimJuzIndex(1))));
  await tester.pumpAndSettle();
  expect(find.byKey(const ValueKey(MqKeys.hatimSelectPage)), findsOneWidget);
}

Future<void> checkHatimSelectPage(WidgetTester tester) async {
  await tester.pumpAndSettle();
  expect(find.byKey(const ValueKey(MqKeys.hatimSelectPage)), findsOneWidget);
  await tester.takeScreenshot(Screenshots.hatimPages);
}
