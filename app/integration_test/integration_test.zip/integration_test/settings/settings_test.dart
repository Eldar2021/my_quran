import 'package:flutter/foundation.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mq_ci_keys/mq_ci_keys.dart';
import '../extensions/extensions.dart';
import '../navigation.dart';

Future<void> checkSettingsView(WidgetTester tester) async {
  await tester.pumpAndSettle();
  expect(find.byKey(const ValueKey(MqKeys.settingsView)), findsOneWidget);
  await tester.takeScreenshot(Screenshots.settingsInit);
}

Future<void> checkSettingsGender(WidgetTester tester) async {
  await tester.pumpAndSettle();
  expect(find.byKey(const ValueKey(MqKeys.settingsGenderLang)), findsOneWidget);
  await tester.tap(find.byKey(const ValueKey(MqKeys.settingsGenderLang)));
  await tester.pumpAndSettle();
  expect(find.byKey(const ValueKey(MqKeys.settingsGenderLangPage)), findsOneWidget);
  await tester.tap(find.byKey(const ValueKey(MqKeys.settingsGenderMale)));
  await tester.takeScreenshot(Screenshots.settingsGenderMale);
  await tester.tap(find.byKey(const ValueKey(MqKeys.settingsGenderFemale)));
  await tester.takeScreenshot(Screenshots.settingsGenderFemale);
  await backPage(tester);
}

Future<void> checkSettingsAboutUs(WidgetTester tester) async {
  await tester.pumpAndSettle();
  expect(find.byKey(const ValueKey(MqKeys.settingsAboutUs)), findsOneWidget);
  await tester.tap(find.byKey(const ValueKey(MqKeys.settingsAboutUs)));
  await tester.pumpAndSettle();
  expect(find.byKey(const ValueKey(MqKeys.settingsAboutUsPage)), findsOneWidget);
  await tester.takeScreenshot(Screenshots.settingsAboutUsPage);
  await backPage(tester);
}

Future<void> checkSettingsContactUs(WidgetTester tester) async {
  await tester.pumpAndSettle();
  expect(find.byKey(const ValueKey(MqKeys.settingsContactUs)), findsOneWidget);
  await tester.tap(find.byKey(const ValueKey(MqKeys.settingsContactUs)));
  await tester.pumpAndSettle();
  expect(find.byKey(const ValueKey(MqKeys.settingsContactUsPage)), findsOneWidget);
  await tester.takeScreenshot(Screenshots.settingsContactUsPage);
  await backPage(tester);
}

Future<void> checkSettingsDevelopers(WidgetTester tester) async {
  await tester.pumpAndSettle();
  expect(find.byKey(const ValueKey(MqKeys.settingsDevelopers)), findsOneWidget);
  await tester.tap(find.byKey(const ValueKey(MqKeys.settingsDevelopers)));
  await tester.pumpAndSettle();
  expect(find.byKey(const ValueKey(MqKeys.settingsDevelopersPage)), findsOneWidget);
  await tester.takeScreenshot(Screenshots.settingsDevelopersPage);
  await backPage(tester);
}

Future<void> checkSettingsTheme(WidgetTester tester) async {
  await tester.pumpAndSettle();
  expect(find.byKey(const ValueKey(MqKeys.settingsTheme)), findsOneWidget);
  await tester.tap(find.byKey(const ValueKey(MqKeys.settingsTheme)));
  await tester.pumpAndSettle();
  expect(find.byKey(const ValueKey(MqKeys.settingsThemePage)), findsOneWidget);
  await tester.tap(find.byKey(ValueKey(MqKeys.settingsThemeColorName('Orange'))));
  await tester.takeScreenshot(Screenshots.settingsThemePageLightGreen);
  await tester.tap(find.byKey(ValueKey(MqKeys.settingsThemeColorName('Blue'))));
  await tester.takeScreenshot(Screenshots.settingsThemePageLightBlue);
  await backPage(tester);
}

Future<void> checkLogout(WidgetTester tester) async {
  await tester.pumpAndSettle();
  expect(find.byKey(const ValueKey(MqKeys.settingsView)), findsOneWidget);
  await tester.tap(find.byKey(const ValueKey(MqKeys.logoutButton)));
  await tester.pumpAndSettle();
  await tester.takeScreenshot(Screenshots.logout);
}
