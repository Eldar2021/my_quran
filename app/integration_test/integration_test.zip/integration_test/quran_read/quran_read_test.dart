import 'package:flutter/foundation.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mq_ci_keys/mq_ci_keys.dart';
import '../extensions/extensions.dart';

Future<void> checkQuranReadJuzs(WidgetTester tester) async {
  await tester.pumpAndSettle();
  expect(find.byKey(const ValueKey(MqKeys.quaranReadInitPage)), findsOneWidget);
  await tester.tap(find.byKey(const ValueKey(MqKeys.quaranReadJuzs)));
  await tester.pumpAndSettle();
  expect(find.byKey(ValueKey(MqKeys.quranReadJus(2))), findsOneWidget);
  await tester.takeScreenshot(Screenshots.readQuranJuzs);
}

Future<void> checkQuranReadSurahs(WidgetTester tester) async {
  await tester.pumpAndSettle();
  expect(find.byKey(const ValueKey(MqKeys.quaranReadInitPage)), findsOneWidget);
  await tester.tap(find.byKey(const ValueKey(MqKeys.quaranReadSurahs)));
  await tester.pumpAndSettle();
  expect(find.byKey(ValueKey(MqKeys.quranReadSurah(2))), findsOneWidget);
  await tester.takeScreenshot(Screenshots.readQuranSurahs);
}

Future<void> readBaqara(WidgetTester tester) async {
  await tester.pumpAndSettle();
  expect(find.byKey(ValueKey(MqKeys.quranReadSurah(1))), findsOneWidget);
  await tester.tap(find.byKey(ValueKey(MqKeys.quranReadSurah(1))));
  await tester.pumpAndSettle();
  expect(find.byKey(const ValueKey(MqKeys.quranReadView)), findsOneWidget);
  await tester.takeScreenshot(Screenshots.readQuranBaqarah);
}

Future<void> checkQuranSettings(WidgetTester tester) async {
  await tester.pumpAndSettle();
  expect(find.byKey(const ValueKey(MqKeys.quranReadSettings)), findsOneWidget);
  await tester.tap(find.byKey(const ValueKey(MqKeys.quranReadSettings)));
  await tester.pumpAndSettle();
  await tester.takeScreenshot(Screenshots.readQuranSettings);
  await tester.tap(find.byKey(const ValueKey(MqKeys.quranReadSettingsBack)));
  await tester.pumpAndSettle();
}

Future<void> backQuranReadInitPageFromQuranReadView(WidgetTester tester) async {
  await tester.pumpAndSettle();
  expect(find.byKey(const ValueKey(MqKeys.quranReadView)), findsOneWidget);
  await tester.tap(find.backButton());
  await tester.pumpAndSettle();
  expect(find.byKey(const ValueKey(MqKeys.quaranReadInitPage)), findsOneWidget);
}
