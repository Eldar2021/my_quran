import 'package:flutter/foundation.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mq_ci_keys/mq_ci_keys.dart';
import '../extensions/extensions.dart';

Future<void> checkQuranAudioView(WidgetTester tester) async {
  await tester.pumpAndSettle();
  expect(find.byKey(const ValueKey(MqKeys.quranAudioView)), findsOneWidget);
  expect(find.byKey(const ValueKey(MqKeys.quranAudioBottomSheet)), findsOneWidget);
  await tester.takeScreenshot(Screenshots.quranAudioInit);
}

Future<void> playFatihaAndBaqara(WidgetTester tester) async {
  await tester.pumpAndSettle();
  expect(find.byKey(const ValueKey(MqKeys.quranAudioPlayPause)), findsOneWidget);
  await tester.tap(find.byKey(const ValueKey(MqKeys.quranAudioPlayPause)));
  await Future<void>.delayed(const Duration(seconds: 5));
  await tester.takeScreenshot(Screenshots.quranAudioPlayFatiha);
  await tester.tap(find.byKey(ValueKey(MqKeys.quranAudioSurahIndex(1))));
  await Future<void>.delayed(const Duration(seconds: 5));
  await tester.takeScreenshot(Screenshots.quranAudioPlayBaqara);
  await tester.tap(find.byKey(const ValueKey(MqKeys.quranAudioPlayPause)));
  await tester.pumpAndSettle();
}
