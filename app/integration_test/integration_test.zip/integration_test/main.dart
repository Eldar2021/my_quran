import 'package:flutter_test/flutter_test.dart';
import 'package:integration_test/integration_test.dart';
import 'package:my_quran/main.dart' as app;
import 'extensions/extensions.dart';
// import 'navigation.dart';
import 'login/login_test.dart';
// import 'home/home_test.dart';
// import 'hatim/hatim_test.dart';
// import 'quran_read/quran_read_test.dart';
// import 'quran_audio/quran_audio_test.dart';
// import 'settings/settings_test.dart';

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  group('Hatim App Integration Test', () {
    setUpAll(() async {
      await app.main(isIntegrationTest: true);
      // await tester.pumpWidget(const MyApp());
      // await Future<void>.delayed(const Duration(milliseconds: 500));
    });

    // Login Testleri
    group('Login', () {
      testWidgets('check-login-select-language', selectLang);
      // testWidgets('check-login-select-gender', selectGender);
      // testWidgets('create-account', loginNext);
      // testWidgets('sign-in-with-google-account', loginWithGoogle);
    });

    // Home Testleri
    // group('Home', () {
    //   testWidgets('check-home-view', homeInit);
    //   testWidgets('go-hatim', goToHatimPageFromHome);
    // });

    // // Hatim Testleri
    // group('Hatim', () {
    //   testWidgets('check-hatim-juzs-page', checkHatimJuzs);
    //   testWidgets('go-hatim-select-pages-view', tapHatimJuz);
    //   testWidgets('check-hatim-select-pages-view', checkHatimSelectPage);
    //   testWidgets('back-hatim-select-juzs-view', backPage);
    //   testWidgets('back-home-view', backPage);
    // });

    // // Quran-Read Testleri
    // group('Quran-Read', () {
    //   testWidgets('go-quran-read', goBottomQuranRead);
    //   testWidgets('check-quran-read-juzs', checkQuranReadJuzs);
    //   testWidgets('check-quran-read-surahs', checkQuranReadSurahs);
    //   testWidgets('read-baqara-read-view', readBaqara);
    //   testWidgets('check-quran-settings', checkQuranSettings);
    //   testWidgets('back-quran-read', backQuranReadInitPageFromQuranReadView);
    // });

    // // Quran-Audio Testleri
    // group('Quran-Audio', () {
    //   testWidgets('go-quran-audio', goBottomQuranAudio);
    //   testWidgets('check-quran-audio-view', checkQuranAudioView);
    //   testWidgets('play-fatiha-and-baqara', playFatihaAndBaqara);
    // });

    // // Settings Testleri
    // group('Settings', () {
    //   testWidgets('go-home', goBottomHome);
    //   testWidgets('go-settings', goSettings);
    //   testWidgets('check-settings-view', checkSettingsView);
    //   testWidgets('check-settings-gender-language', checkSettingsGender);
    //   testWidgets('check-settings-about-us', checkSettingsAboutUs);
    //   testWidgets('check-settings-contact-us', checkSettingsContactUs);
    //   testWidgets('check-settings-developers', checkSettingsDevelopers);
    //   testWidgets('check-settings-theme', checkSettingsTheme);
    //   // testWidgets('check-logout', (tester) => checkLogout(tester));
    // });

    tearDownAll(() async {
      await addDelay(300);
    });
  });
}
