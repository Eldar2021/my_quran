import 'package:flutter/foundation.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mq_ci_keys/mq_ci_keys.dart';

Future<void> goBottomHome(WidgetTester tester) async {
  await tester.tap(find.byKey(const ValueKey(MqKeys.home)));
  await tester.pumpAndSettle();
}

Future<void> goBottomQuranRead(WidgetTester tester) async {
  await tester.tap(find.byKey(const ValueKey(MqKeys.quaranRead)));
  await tester.pumpAndSettle();
}

Future<void> goBottomQuranAudio(WidgetTester tester) async {
  await tester.tap(find.byKey(const ValueKey(MqKeys.quranAudio)));
  await tester.pumpAndSettle();
}

Future<void> goSettings(WidgetTester tester) async {
  await tester.tap(find.byKey(const ValueKey(MqKeys.settings)));
  await tester.pumpAndSettle();
}

Future<void> backPage(WidgetTester tester) async {
  await tester.tap(find.backButton());
  await tester.pumpAndSettle();
}
