// import 'dart:io';
import 'package:flutter_test/flutter_test.dart';

extension ScreenshotExtension on WidgetTester {
  Future<void> takeScreenshot(
    String name, {
    String directory = '../screenshots',
    bool waitUntilNoTransientCallbacks = true,
  }) async {
    if (waitUntilNoTransientCallbacks) {
      await pumpAndSettle(const Duration(seconds: 30));
    }
    // final pixels = await binding.takeScreenshot(name);
    // final directoryPath = directory.endsWith('/') ? directory : '$directory/';
    // final file = await File('$directoryPath$name.png').create(recursive: true);
    // await file.writeAsBytes(pixels);
    // // print('Screenshot $name');
  }
}
