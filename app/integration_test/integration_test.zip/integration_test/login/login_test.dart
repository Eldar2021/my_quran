import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mq_ci_keys/mq_ci_keys.dart';
import '../extensions/extensions.dart';

Future<void> selectLang(WidgetTester tester) async {
  await tester.pumpAndSettle();
  expect(find.byKey(const Key('login-initial')), findsOneWidget);
  await tester.takeScreenshot(Screenshots.loginLangEnPage);
}

Future<void> selectGender(WidgetTester tester) async {
  await tester.pumpAndSettle();
  expect(find.byKey(const Key(MqKeys.loginInitial)), findsOneWidget);
  await tester.tap(find.byKey(Key(MqKeys.genderName('female'))));
  await tester.pumpAndSettle();
  await tester.takeScreenshot(Screenshots.loginGenderFemalePage);
  await tester.tap(find.byKey(Key(MqKeys.genderName('male'))));
  await tester.pumpAndSettle();
  await tester.takeScreenshot(Screenshots.loginGenderMalePage);
}

Future<void> sendOtp(WidgetTester tester) async {
  await tester.pumpAndSettle();
  expect(find.byKey(const Key(MqKeys.signInView)), findsOneWidget);
  await tester.tap(find.byKey(const Key(MqKeys.emailTextField)));
  await tester.enterText(find.byKey(const Key(MqKeys.emailTextField)), 'test@example.com');
  await tester.tap(find.byKey(const Key(MqKeys.sendOtp)));
  await tester.pumpAndSettle();
  await tester.takeScreenshot(Screenshots.sendOtp);
}

Future<void> verifyOtp(WidgetTester tester) async {
  await tester.pumpAndSettle();
  expect(find.byKey(const Key(MqKeys.verifyOtpView)), findsOneWidget);
  await tester.tap(find.byKey(const Key(MqKeys.otpTextField)));
  await tester.enterText(find.byKey(const Key(MqKeys.otpTextField)), '1234');
  await tester.tap(find.byKey(Key(MqKeys.loginTypeName('email'))));
  await tester.pumpAndSettle();
  await tester.takeScreenshot(Screenshots.loginEmail);
  await Future<void>.delayed(const Duration(seconds: 1));
}

Future<void> loginWithGoogle(WidgetTester tester) async {
  await tester.pumpAndSettle();
  expect(find.byKey(const Key(MqKeys.signInView)), findsOneWidget);
  await tester.takeScreenshot(Screenshots.loginGooglePage);
  await tester.tap(find.byKey(Key(MqKeys.loginTypeName('google'))));
  await tester.pumpAndSettle();
  await Future<void>.delayed(const Duration(seconds: 1));
}

Future<void> loginNext(WidgetTester tester) async {
  await tester.pumpAndSettle();
  expect(find.byKey(const Key(MqKeys.loginNext)), findsOneWidget);
  await tester.tap(find.byKey(const Key(MqKeys.loginNext)));
  await tester.pumpAndSettle();
}
