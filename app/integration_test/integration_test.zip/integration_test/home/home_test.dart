import 'package:flutter/foundation.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mq_ci_keys/mq_ci_keys.dart';
import '../extensions/extensions.dart';

Future<void> homeInit(WidgetTester tester) async {
  await tester.pumpAndSettle();
  expect(find.byKey(const ValueKey(MqKeys.homeView)), findsOneWidget);
  await addDelay(500);
  await tester.takeScreenshot(Screenshots.homeInit);
}

Future<void> goToHatimPageFromHome(WidgetTester tester) async {
  await tester.pumpAndSettle();
  await tester.scrollUntilVisible(
    find.byKey(const ValueKey(MqKeys.participantToHatim)),
    -100,
    scrollable: find.byKey(const ValueKey(MqKeys.homeListView)),
  );
  await tester.tap(find.byKey(const ValueKey(MqKeys.participantToHatim)));
  await tester.pumpAndSettle();
}
